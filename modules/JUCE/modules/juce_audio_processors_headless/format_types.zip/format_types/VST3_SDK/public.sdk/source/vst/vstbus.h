//-----------------------------------------------------------------------------
// Project     : VST SDK
//
// Category    : Helpers
// Filename    : public.sdk/source/vst/vstbus.h
// Created by  : Steinberg, 03/2008
// Description : VST Bus Implementation
//
//-----------------------------------------------------------------------------
// This file is part of a Steinberg SDK. It is subject to the license terms
// in the LICENSE file found in the top-level directory of this distribution
// and at www.steinberg.net/sdklicenses.
// No part of the SDK, including this file, may be copied, modified, propagated,
// or distributed except according to the terms contained in the LICENSE file.
//-----------------------------------------------------------------------------

#pragma once

#include "base/source/fobject.h"
#include "pluginterfaces/vst/ivstcomponent.h"
#include "pluginterfaces/vst/ivstaudioprocessor.h"

#include <string>
#if defined(SMTG_CPP_17) && SMTG_CPP_17
#include <string_view>
#endif
#include <vector>

//------------------------------------------------------------------------
namespace Steinberg {
namespace Vst {

//------------------------------------------------------------------------
/** Basic Bus object.
\ingroup vstClasses 
*/
class Bus: public FObject
{
public:
//------------------------------------------------------------------------
	/** Constructor. */
	Bus (const TChar* name, BusType busType, int32 flags);

	/** Returns true if the bus is active. */
	TBool isActive () const { return active; }

	/** Activates the bus. */
	void setActive (TBool state) { active = state; }

#if defined(SMTG_CPP_17) && SMTG_CPP_17
	/** Sets a new name for this bus. */
	void setName (std::u16string_view newName) { name = newName; }
#else
	/** Sets a new name for this bus. */
	void setName (const std::u16string& newName) { name = newName; }
#endif

	/** Sets a new busType for this bus. */
	void setBusType (BusType newBusType) { busType = newBusType; }

	/** Sets a new flags for this bus. */
	void setFlags (uint32 newFlags) { flags = newFlags; }

	/** Gets the BusInfo of this bus. */
	virtual bool getInfo (BusInfo&);

	OBJ_METHODS (Vst::Bus, FObject)
//------------------------------------------------------------------------
protected:
	std::u16string name;		///< name
	BusType busType;			///< kMain or kAux, see \ref BusTypes
	int32 flags;				///< flags, see \ref BusInfo::BusFlags
	TBool active;				///< activation state
};

//------------------------------------------------------------------------
/** Description of an Event Bus.
\ingroup vstClasses
*/
class EventBus: public Bus
{
public:
//------------------------------------------------------------------------
	/** Constructor of an EventBus. */
	EventBus (const TChar* name, BusType busType, int32 flags, int32 channelCount);

	//---from Bus-------
	/** Gets the BusInfo associated to this Event bus. */
	bool getInfo (BusInfo& info) SMTG_OVERRIDE;

	OBJ_METHODS (Vst::EventBus, Vst::Bus);

//------------------------------------------------------------------------
protected:
	int32 channelCount;
};

//------------------------------------------------------------------------
/** Description of an Audio Bus.
\ingroup vstClasses 
*/
class AudioBus: public Bus
{
public:
//------------------------------------------------------------------------
	AudioBus (const TChar* name, BusType busType, int32 flags, SpeakerArrangement arr);

	/** Gets the speaker arrangement defining this Audio bus. */
	SpeakerArrangement getArrangement () const { return speakerArr; }

	/** Sets the speaker arrangement defining this Audio bus. */
	void setArrangement (const SpeakerArrangement& arr) { speakerArr = arr; }

	//---from Bus---------------------
	/** Gets the BusInfo associated to this Audio bus. */
	bool getInfo (BusInfo& info) SMTG_OVERRIDE;

	OBJ_METHODS (Vst::AudioBus, Vst::Bus)

//------------------------------------------------------------------------
protected:
	SpeakerArrangement speakerArr;
};

//------------------------------------------------------------------------
/** List of Busses.
\ingroup vstClasses 
*/
class BusList: public FObject, public std::vector<IPtr<Vst::Bus> >
{
public:
//------------------------------------------------------------------------
	/** Constructor. */
	BusList (MediaType type, BusDirection dir);

	/** Returns the BusList Type. See \ref MediaType */
	MediaType getType () const { return type; }

	/** Returns the BusList direction. See \ref BusDirection */
	BusDirection getDirection () const { return direction; }

	OBJ_METHODS (Vst::BusList, FObject);

//------------------------------------------------------------------------
protected:
	MediaType type;
	BusDirection direction;
};

//------------------------------------------------------------------------
} // namespace Vst
} // namespace Steinberg
